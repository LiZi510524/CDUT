#ifndef STACK_H
#define STACK_H

#define OK 1
#define ERROR 0
#define OVERFLOW -2

typedef int Status;

typedef struct SNode {
    int data;               // 数据域
    struct SNode *next;    // 指向下一个节点的指针
} SNode, *LinkStack;

// 函数声明
Status InitStack(LinkStack *S);  // 初始化栈
int StackEmpty(LinkStack S);      // 判断栈是否为空
Status Push(LinkStack *S, int e); // 入栈操作
Status Pop(LinkStack *S, int *e); // 出栈操作

#endif // STACK_H