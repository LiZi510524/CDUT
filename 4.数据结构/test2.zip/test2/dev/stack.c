#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

Status InitStack(LinkStack *S) {  // 初始化栈
    *S = NULL;  // 设置栈为空
    return OK;
}

int StackEmpty(LinkStack S) {  // 判断栈是否为空
    return (S == NULL) ? 1 : 0; // 为空返回 1，不为空返回 0
}

Status Push(LinkStack *S, int e) {  // 入栈操作
    LinkStack p = (LinkStack)malloc(sizeof(SNode)); // 分配新节点
    if (!p) {
        return OVERFLOW; // 存储分配失败
    }
    p->data = e;       // 设置数据
    p->next = *S;     // 新节点指向原栈顶
    *S = p;           // 更新栈顶指针
    return OK;
}

Status Pop(LinkStack *S, int *e) {  // 出栈操作
    if (*S == NULL) {
        return ERROR; // 栈空
    }
    LinkStack p = *S; // 保存栈顶节点
    *e = p->data;     // 返回栈顶数据
    *S = (*S)->next;  // 更新栈顶指针
    free(p);         // 释放栈顶节点
    return OK;
}