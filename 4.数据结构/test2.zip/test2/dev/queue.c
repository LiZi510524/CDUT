#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "queue.h"

int countofcustmer=0;
SqQueue custmers;

int InitQueue(SqQueue *Q) {  // 构造一个空队列Q
    Q->base = (Person *)malloc(MAXQSIZE * sizeof(Person));
    if (!Q->base)
        exit(OVERFLOW);  // 存储分配失败
    Q->front = Q->rear = 0;  // 头指针和尾指针置为零，队列为空
    return OK;
}

int EnQueue(SqQueue *Q, Person e) {  // 插入元素e为Q的新的队尾元素
    if ((Q->rear + 1) % MAXQSIZE == Q->front)  // 判断队满
        return ERROR;
    Q->base[Q->rear] = e;  // 新元素插入队尾
    Q->rear = (Q->rear + 1) % MAXQSIZE;  // 队尾指针加1
    return OK;
}

int QueueEmpty(SqQueue *Q) {
    return (Q->front == Q->rear) ? OK : ERROR;  // 判断队空
}

int QueueLength(SqQueue Q) {  // 返回Q的元素个数，即队列的长度
    return (Q.rear - Q.front + MAXQSIZE) % MAXQSIZE;
}

int DeQueue(SqQueue *Q, Person *e) {  // 删除Q的队头元素
    if (Q->front == Q->rear)
        return ERROR;  // 队空
    *e = Q->base[Q->front];  // 保存队头元素
    Q->front = (Q->front + 1) % MAXQSIZE;  // 队头指针加1
    return OK;
}

Person GetHead(SqQueue Q) {  // 返回Q的队头元素
    if (Q.front != Q.rear)  // 队列非空
        return Q.base[Q.front];  // 返回队头元素的值
    Person empty = {"", ""};  // 返回空值
    return empty;
}

void ShowInfo(SqQueue Q) {  // 显示队列信息
    printf("\n当前排队人数:%d\n", QueueLength(Q));
    // 这里需要一个全局变量 countofcustmer，如果需要的话
    printf("已办理完人数: %d\n", countofcustmer - QueueLength(Q));
    Person p = GetHead(Q);
    printf("正在办理业务的客户为：%s %s\n", p.name, p.sex);
}

void Showfront(SqQueue Q){
    printf("此时前面 %d 人排队中",QueueLength(Q)-1);
}

void Showsum(SqQueue Q){
    printf("截至目前总共办理客户数：%d",countofcustmer - QueueLength(Q));
}