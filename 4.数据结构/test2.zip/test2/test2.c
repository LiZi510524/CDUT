#include <stdio.h>
#include "queue.h"
#include "stack.h"

void conversion(int N) {//对于任意一个非负十进制数，打印输出与其等值的八进制数
	int e;
	LinkStack S;
	InitStack(&S); //初始化空栈S
	while (N) //当N非零时,循环
	{
		Push(&S, N % 8); //把N与8求余得到的八进制数压入栈S
		N = N / 8; //N更新为N与8的商
	}
	while (!StackEmpty(S)) //当栈S非空时，循环
	{
		Pop(&S, &e); //弹出栈顶元素e
		printf("%d",e); //输出e
	}
}

int main()
{
    int no,i,countofconv,choose;

    Person custmer;
    int input[10];
    no=-1;

    while (no!=0)
    {
        printf("Test2 Stack and Queue\n");
        printf("1.Stack\n");
        printf("2.Queue\n");
        printf("0.Quit\n");
        printf("Please Choose:\n");
        scanf_s("%d",&i);
        /* code */
    }
    
    return 0;
}